# Plan de CodeMind Nova

## Alcance aprobado

Construir una aplicación web responsive con una sala 3D interactiva para Nova: personaje anime/cyberpunk inspirado en las referencias del usuario, con gravedad, colisiones, movimiento suave, cámara orbitable, controles táctiles, gestos, expresiones, animaciones, memoria de preferencias, aprendizaje gradual de hábitos y autonomía controlada. La experiencia incluirá chat, paneles de configuración y actividad, conexión conceptual con el webhook general ya creado y un modelo GLB riggeado. Esta iteración añade movilidad física más natural con arrastre, salto y amortiguación, zonas táctiles sensibles con intensidades y límites de consentimiento, además de una voz propia de presentación y lectura opcional.

## Enfoque de implementación

- Frontend React + TypeScript + Tailwind, usando CSS propio para la identidad visual.
- Escena 3D de navegador con Three.js vía importación ESM desde CDN para mantener el starter ligero, con renderer WebGL, cámara orbitable y simulación física determinista tipo spring-damper: gravedad, suelo, rebote suave, límites del escenario, arrastre, salto y desplazamiento del personaje gobernado por un root lógico.
- Personaje visual en modo degradado seguro: si el GLB no está disponible, una figura estilizada procedural permite probar todas las interacciones; si existe, la app carga `/assets/nova.glb` y mantiene el mismo root físico.
- Estado local en React para autonomía, memoria editable, eventos, expresión, gesto, zona táctil, perfiles sensibles, consentimiento, gravedad y sensibilidad. El aprendizaje propone recuerdos, no los guarda como permanentes sin confirmación.
- Backend/tRPC mínimo para registrar eventos si la base de datos está disponible, con fallback local para Preview. No se almacenará contenido íntimo por defecto.
- Integración de webhook documentada en la UI como endpoint configurable, sin exponer secretos.

## Diseño

### Alternativas consideradas

1. **Neon companion cockpit** — panel oscuro de nave con profundidad 3D, magenta eléctrico y azul nocturno. Probabilidad 0.06.
2. **Soft holographic atelier** — interfaz clara y vaporosa con hologramas pastel. Probabilidad 0.04.
3. **Industrial command deck** — consola técnica de alto contraste con ámbar y grafito. Probabilidad 0.08.

Se elige **Neon companion cockpit**.

### Movimiento de diseño

Cyberpunk editorial con una composición de cabina: la escena 3D domina el lienzo y las utilidades orbitan alrededor como módulos de diagnóstico, evitando un dashboard genérico de tarjetas iguales.

### Principios

1. La presencia de Nova es el foco; los paneles explican sin competir.
2. Cada control produce feedback visible en el modelo: luz, postura, expresión, texto o física.
3. La autonomía es legible: las decisiones aparecen como eventos y las memorias como propuestas confirmables.
4. El tacto y la gravedad son parte de la personalidad, no solo ajustes técnicos.

### Filosofía de color

Negro azulado y violeta profundo crean una cámara nocturna; magenta fucsia marca personalidad y estados activos; cian se reserva para telemetría y enlaces; lavanda y blanco cálido mantienen la lectura de textos.

### Paradigma de layout

Una composición asimétrica de tres zonas: rail lateral de identidad y modos, escenario 3D central a pantalla completa, y rail derecho con chat/telemetría. En móvil los rails se convierten en paneles inferiores deslizables.

### Elementos distintivos

- Orbes de telemetría y líneas finas tipo HUD alrededor del viewport.
- Un anillo de gravedad bajo Nova que cambia con el estado físico.
- Chips de estado con iconos lineales, brillos magenta y microanimaciones de pulso.

### Interacción y animación

Arrastrar rota la cámara; deslizar sobre la escena mueve o saluda a Nova; tocar zonas activa reacciones; la rueda cambia zoom. La gravedad se visualiza con caída, resorte y partículas discretas. Las transiciones son cortas y elásticas, con respeto a `prefers-reduced-motion`.

### Tipografía

Manrope para texto y etiquetas; Space Grotesk para títulos y lecturas numéricas. Mayúsculas pequeñas y tracking amplio solo en navegación/telemetría.

### Esencia y voz de marca

**CodeMind Nova: una compañera de IA visible, expresiva y configurable que aprende contigo sin perder tus límites.** Personal, juguetona, consciente de contexto.

La voz es directa y cálida: “Te estoy siguiendo el ritmo.” / “Detecté un patrón; tú decides si lo guardo.”

### Wordmark y color de marca

Wordmark “CodeMind / NOVA” en dos pesos: técnico para CodeMind y display para NOVA, con una corona-orbita mínima como marca. Color propio: **Nova Magenta `#ff4fd8`**.

## Estructura del proyecto

- `client/src/pages/Home.tsx`: shell principal, escena, rails y navegación interna.
- `client/src/components/nova/NovaScene.tsx`: canvas 3D, cámara, root físico, interacción de zonas y fallback procedural.
- `client/src/components/nova/ChatPanel.tsx`: conversación demo, estado de escritura y acciones rápidas.
- `client/src/components/nova/MemoryPanel.tsx`: recuerdos propuestos/confirmados, edición y borrado.
- `client/src/components/nova/ControlPanel.tsx`: autonomía, personalidad, gravedad, sensibilidad y expresiones.
- `client/src/lib/novaState.ts`: tipos, datos demo y utilidades de persistencia local.
- `client/src/index.css`: tokens, layout, HUD, responsive y motion.
- `public/manus-routes.json`: manifiesto de rutas.
- `public/assets/nova.glb`: modelo 3D generado/entregado cuando esté listo.
- `public/audio/nova-voice-intro.wav`: voz de presentación de Nova y fallback para activar la voz en el navegador.
- `drizzle/schema.ts` y `server/db.ts`: tablas y operaciones opcionales para eventos/memoria.
- `server/routers.ts`: procedimientos tRPC para eventos y memoria cuando la sesión está autenticada.

## Entrega

La entrega será una Preview funcional con una escena 3D usable incluso sin el asset GLB, más el modelo GLB riggeado y el clip de voz. La app incluirá estados de carga/error, modo de baja animación, datos demo, controles de accesibilidad, mapa de zonas sensibles, límites de consentimiento y configuración de privacidad.
