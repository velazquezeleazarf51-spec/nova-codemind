import { describe, expect, it } from "vitest";
import { clientKey, createRateLimiter } from "./_core/rateLimit";

describe("createRateLimiter", () => {
  it("permite hasta el máximo y luego bloquea con tiempo de espera", () => {
    const limiter = createRateLimiter({ windowMs: 1000, max: 3 });
    expect(limiter.check("a", 0).allowed).toBe(true);
    expect(limiter.check("a", 100).allowed).toBe(true);
    expect(limiter.check("a", 200).remaining).toBe(0);
    const blocked = limiter.check("a", 300);
    expect(blocked.allowed).toBe(false);
    expect(blocked.retryAfterMs).toBe(700);
  });

  it("vuelve a permitir cuando la ventana se desliza", () => {
    const limiter = createRateLimiter({ windowMs: 1000, max: 1 });
    expect(limiter.check("a", 0).allowed).toBe(true);
    expect(limiter.check("a", 999).allowed).toBe(false);
    expect(limiter.check("a", 1001).allowed).toBe(true);
  });

  it("lleva la cuenta por separado para cada clave", () => {
    const limiter = createRateLimiter({ windowMs: 1000, max: 1 });
    expect(limiter.check("a", 0).allowed).toBe(true);
    expect(limiter.check("b", 0).allowed).toBe(true);
    expect(limiter.check("a", 1).allowed).toBe(false);
  });
});

describe("clientKey", () => {
  it("prefiere el usuario autenticado y si no usa la IP", () => {
    expect(clientKey({ ip: "1.2.3.4" }, 7)).toBe("user:7");
    expect(clientKey({ ip: "1.2.3.4" }, null)).toBe("ip:1.2.3.4");
    expect(clientKey({ socket: { remoteAddress: "9.9.9.9" } })).toBe("ip:9.9.9.9");
    expect(clientKey({})).toBe("ip:unknown");
  });
});
