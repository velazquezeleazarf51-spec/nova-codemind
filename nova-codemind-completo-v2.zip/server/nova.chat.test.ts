import { beforeEach, describe, expect, it, vi } from "vitest";
import type { TrpcContext } from "./_core/context";
import { CHAT_MAX_MESSAGES_PER_REQUEST, CHAT_RATE_LIMIT_MAX } from "../shared/nova";

vi.mock("./_core/llm", () => ({ invokeLLM: vi.fn() }));

import { invokeLLM } from "./_core/llm";
import { appRouter } from "./routers";

const llm = vi.mocked(invokeLLM);

// Cada prueba usa una IP distinta porque el limitador vive en memoria del módulo.
let ipCounter = 0;
const caller = (ip = `10.0.0.${++ipCounter}`) =>
  appRouter.createCaller({ user: null, req: { ip, headers: {} } as TrpcContext["req"], res: {} as TrpcContext["res"] });

const messages = (n: number) =>
  Array.from({ length: n }, (_, i) => ({ role: i % 2 === 0 ? ("user" as const) : ("assistant" as const), content: `m${i}` }));

beforeEach(() => {
  llm.mockReset();
  llm.mockResolvedValue({ model: "test-model", choices: [{ message: { content: "  Hola, aquí estoy.  " } }] } as never);
});

describe("nova.chat", () => {
  it("responde y recorta el texto del modelo", async () => {
    const result = await caller().nova.chat({ messages: messages(1) });
    expect(result).toEqual({ reply: "Hola, aquí estoy.", model: "test-model" });
  });

  it("acepta hasta el máximo de mensajes y rechaza más", async () => {
    const c = caller();
    await expect(c.nova.chat({ messages: messages(CHAT_MAX_MESSAGES_PER_REQUEST - 1) })).resolves.toBeDefined();
    await expect(c.nova.chat({ messages: messages(CHAT_MAX_MESSAGES_PER_REQUEST + 1) })).rejects.toThrow();
  });

  it("rechaza mensajes vacíos", async () => {
    await expect(caller().nova.chat({ messages: [{ role: "user", content: "   " }] })).rejects.toThrow();
  });

  it("mantiene las reglas de consentimiento en el prompt del sistema", async () => {
    await caller().nova.chat({ messages: messages(1), autonomy: "asistente" });
    const system = llm.mock.calls[0][0].messages[0] as { content: string };
    expect(system.content).toContain("consentimiento");
    expect(system.content).toContain("detente");
  });

  it("limita las peticiones por cliente con TOO_MANY_REQUESTS", async () => {
    const c = caller("203.0.113.9");
    for (let i = 0; i < CHAT_RATE_LIMIT_MAX; i++) await c.nova.chat({ messages: messages(1) });
    await expect(c.nova.chat({ messages: messages(1) })).rejects.toMatchObject({ code: "TOO_MANY_REQUESTS" });
    expect(llm).toHaveBeenCalledTimes(CHAT_RATE_LIMIT_MAX);
    // otro cliente no se ve afectado
    await expect(caller("203.0.113.10").nova.chat({ messages: messages(1) })).resolves.toBeDefined();
  });
});
