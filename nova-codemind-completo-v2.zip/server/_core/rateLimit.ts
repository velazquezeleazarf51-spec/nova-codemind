export interface RateLimitResult {
  allowed: boolean;
  remaining: number;
  retryAfterMs: number;
}

export interface RateLimiter {
  check(key: string, now?: number): RateLimitResult;
}

/** Limitador de ventana deslizante en memoria (una sola instancia de servidor). */
export function createRateLimiter({ windowMs, max }: { windowMs: number; max: number }): RateLimiter {
  const hits = new Map<string, number[]>();

  return {
    check(key, now = Date.now()) {
      const cutoff = now - windowMs;
      const recent = (hits.get(key) ?? []).filter(time => time > cutoff);

      if (recent.length >= max) {
        hits.set(key, recent);
        return { allowed: false, remaining: 0, retryAfterMs: Math.max(0, recent[0] + windowMs - now) };
      }

      recent.push(now);
      hits.set(key, recent);

      // Limpieza ocasional para que el mapa no crezca sin límite.
      if (hits.size > 5000) {
        hits.forEach((times, storedKey) => {
          if (!times.some(time => time > cutoff)) hits.delete(storedKey);
        });
      }

      return { allowed: true, remaining: max - recent.length, retryAfterMs: 0 };
    },
  };
}

/**
 * Clave del cliente: usuario autenticado si existe; si no, `req.ip`.
 * `req.ip` solo es fiable detrás de un proxy si Express tiene "trust proxy" configurado
 * (ver server/_core/index.ts). No se lee X-Forwarded-For a mano porque es falsificable.
 */
export function clientKey(req: { ip?: string; socket?: { remoteAddress?: string } }, userId?: number | null): string {
  if (userId != null) return `user:${userId}`;
  return `ip:${req.ip ?? req.socket?.remoteAddress ?? "unknown"}`;
}
