# CodeMind Nova — paquete completo

Este paquete contiene la aplicación web de Nova, su escena Three.js, el modelo GLB riggeado, físicas de gravedad, movimiento con spring-damper, salto, arrastre, cámara orbitable, zonas sensibles, límites de consentimiento, chat, memoria local, webhook y voz en español.

## Ejecutar

1. Instala Node.js y pnpm.
2. Ejecuta `pnpm install`.
3. Ejecuta `pnpm dev`.
4. Abre `http://localhost:3000`.

Para validar antes de entregar: `pnpm check`, `pnpm test` y `pnpm build`.

Android (el bundle web y los plugins de Capacitor ya no vienen en el zip; se regeneran):

```bash
pnpm build && pnpm exec cap sync android
```

Si el servidor está detrás de un proxy, `TRUST_PROXY_HOPS` (por defecto `1`) indica cuántos proxies hay delante; el límite de peticiones del chat usa la IP real del cliente. Usa `0` si el servidor está expuesto directamente.

## Assets principales

- `client/public/assets/nova-animated.glb`: modelo que carga la escena, con clips reales `idle`, `standing_relax` y `walk`.
- `client/public/assets/nova.glb`: modelo original, conservado como fuente; la escena no lo carga.
- `client/public/audio/nova-voice-intro.wav`: voz de presentación de Nova.
- `client/src/components/nova/NovaScene.tsx`: escena 3D, física, gravedad, movilidad y tacto.
- `client/src/lib/novaState.ts`: zonas sensibles, consentimiento, memoria y estado.
- `client/src/components/nova/ChatPanel.tsx`: chat y síntesis de voz opcional.
- `client/src/lib/novaBehavior.ts`: estado continuo de emoción, intención, energía, mirada y habla.
- `client/src/lib/chatHistory.ts`: arma el contexto enviado al modelo (recorta y excluye mensajes solo de interfaz).
- `shared/nova.ts`: límites del chat compartidos entre cliente y servidor.
- `server/_core/rateLimit.ts`: límite de peticiones del chat por cliente.

## Comportamiento vivo y lip-sync

`NovaScene.tsx` recibe `NovaBehaviorState` y combina el estado de la IA con el rig Three.js: respiración, balanceo, mirada, parpadeo, postura y reacción táctil. Cuando el estado `speaking` está activo, el motor busca morph targets con nombres de boca, mandíbula o visema y los anima con un pulso suave sincronizado con la síntesis de voz. Si el GLB no trae morph targets faciales, la escena conserva respiración, mirada y gestos corporales, pero se necesita un GLB con blendshapes para lip-sync fonema por fonema.

## Habitación de Nova

La escena ya no es un personaje aislado sobre un root vacío: incluye una habitación cyberpunk decorada con cama, escritorio, pantalla holográfica, ventana luminosa, estantería, luces magenta/cian y una alfombra central. Nova puede recorrer el espacio con WASD o flechas, recibir una posición destino mediante arrastre y escoger destinos autónomos cada pocos segundos cuando el usuario no la está controlando. Su animación de caminar se selecciona por la velocidad física combinada en X/Z y gira hacia la dirección real de desplazamiento.

## IA conversacional y voz

El modo `Autónoma avanzada` usa el endpoint seguro del servidor y el modelo `gpt-5-mini` para responder de forma dinámica. La voz se reproduce con síntesis de voz del dispositivo y conserva el clip de presentación de Nova como muestra. Si el servidor no está disponible, la interfaz informa del fallo y mantiene las reacciones locales sin ejecutar acciones externas.

La APK compilada desde el bundle local necesita un backend publicado para usar el LLM real; no se incrustan claves privadas en Android. Para apuntar una compilación a un sitio publicado, define `NOVA_REMOTE_URL` antes de sincronizar Capacitor:

```bash
NOVA_REMOTE_URL=https://tu-dominio-publicado.example pnpm exec cap sync android
```

El backend mantiene límites de consentimiento, privacidad y memoria: la autonomía avanzada no autoriza compras, mensajes, cambios de archivos ni memorias permanentes sin confirmación.

No se incluyen `node_modules`, `dist`, `.git`, logs de Preview ni archivos `.env`.

## APK Android

La versión debug instalable se genera desde `android/` con Capacitor. El paquete Android usa el identificador `com.codemind.nova` y contiene la escena 3D, el modelo GLB, el audio y los recursos compilados de la aplicación web. La APK debug no está firmada para publicación en Google Play; sirve para instalación y pruebas directas en Android.

Comandos de recompilación:

```bash
pnpm build
pnpm exec cap sync android
cd android
./gradlew assembleDebug
```
