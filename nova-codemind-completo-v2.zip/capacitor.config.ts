import type { CapacitorConfig } from "@capacitor/cli";

const remoteUrl = process.env.NOVA_REMOTE_URL?.trim();

const config: CapacitorConfig = {
  appId: "com.codemind.nova",
  appName: "CodeMind Nova",
  webDir: "dist/public",
  android: {
    backgroundColor: "#070817",
  },
  ...(remoteUrl ? { server: { url: remoteUrl, cleartext: false } } : {}),
};

export default config;
