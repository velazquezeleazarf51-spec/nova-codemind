package com.codemind.nova;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
