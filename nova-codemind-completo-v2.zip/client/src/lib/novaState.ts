export type Expression =
  | "feliz"
  | "seria"
  | "curiosa"
  | "sorprendida"
  | "coqueta"
  | "pensativa"
  | "enojada"
  | "dormida";

export type AutonomyMode = "asistente" | "companera" | "autonoma";
export type TouchZone = "cabeza" | "cabello" | "hombros" | "manos" | "cuerpo" | "piernas";

export interface TouchProfile {
  label: string;
  response: string;
  expression: Expression;
  intensity: number;
  consent: "permitido" | "confirmar";
}

export const touchProfiles: Record<TouchZone, TouchProfile> = {
  cabeza: { label: "Cabeza", response: "inclina la cabeza y busca tu mirada", expression: "feliz", intensity: 0.82, consent: "permitido" },
  cabello: { label: "Cabello", response: "deja que sus coletas sigan el movimiento", expression: "coqueta", intensity: 0.72, consent: "permitido" },
  hombros: { label: "Hombros", response: "relaja los hombros y se vuelve receptiva", expression: "curiosa", intensity: 0.66, consent: "permitido" },
  manos: { label: "Manos", response: "abre las manos con un gesto de bienvenida", expression: "sorprendida", intensity: 0.58, consent: "permitido" },
  cuerpo: { label: "Cintura / cuerpo", response: "marca el límite y pide confirmar antes de intensificar", expression: "seria", intensity: 0.44, consent: "confirmar" },
  piernas: { label: "Piernas / botas", response: "retrocede un paso y espera una señal clara", expression: "seria", intensity: 0.3, consent: "confirmar" },
};

export interface MemoryItem {
  id: string;
  title: string;
  detail: string;
  confidence: number;
  status: "propuesta" | "confirmada";
  source: string;
  createdAt: string;
}

export interface NovaEvent {
  id: string;
  type: string;
  label: string;
  detail: string;
  time: string;
  accent: "pink" | "cyan" | "yellow" | "purple";
}

export const autonomyLabels: Record<AutonomyMode, string> = {
  asistente: "Asistente",
  companera: "Compañera",
  autonoma: "Autónoma avanzada",
};

export const expressionLabels: Record<Expression, string> = {
  feliz: "Feliz",
  seria: "Seria",
  curiosa: "Curiosa",
  sorprendida: "Sorprendida",
  coqueta: "Coqueta",
  pensativa: "Pensativa",
  enojada: "Enojada",
  dormida: "Dormida",
};

export const expressionEmoji: Record<Expression, string> = {
  feliz: "◠‿◠",
  seria: "•‿•",
  curiosa: "◕‿◕",
  sorprendida: "⊙﹏⊙",
  coqueta: "˘ ³˘",
  pensativa: "◔_◔",
  enojada: "ಠ_ಠ",
  dormida: "－ω－",
};

export const initialMemories: MemoryItem[] = [
  {
    id: "m1",
    title: "Ritmo nocturno",
    detail: "Sueles preferir conversaciones más largas al final del día.",
    confidence: 86,
    status: "confirmada",
    source: "12 interacciones",
    createdAt: "hace 3 días",
  },
  {
    id: "m2",
    title: "Modo directo",
    detail: "Cuando estás concentrado, valoras respuestas breves y accionables.",
    confidence: 74,
    status: "propuesta",
    source: "patrón detectado hoy",
    createdAt: "hace 18 min",
  },
  {
    id: "m3",
    title: "Privacidad íntima",
    detail: "No guardar contenido adulto o sensible sin confirmación explícita.",
    confidence: 100,
    status: "confirmada",
    source: "regla de seguridad",
    createdAt: "configuración",
  },
];

export const initialEvents: NovaEvent[] = [
  { id: "e1", type: "sistema", label: "Sesión iniciada", detail: "Nova está en línea y lista para aprender", time: "ahora", accent: "cyan" },
  { id: "e2", type: "hábitos", label: "Patrón detectado", detail: "Más mensajes después de las 22:00", time: "hace 4 min", accent: "pink" },
  { id: "e3", type: "tacto", label: "Interacción táctil", detail: "Zona: cabello · reacción afectuosa", time: "hace 9 min", accent: "purple" },
  { id: "e4", type: "física", label: "Gravedad calibrada", detail: "1.0 g · amortiguación estable", time: "hace 12 min", accent: "yellow" },
];

export function makeEvent(label: string, detail: string, type: string, accent: NovaEvent["accent"] = "pink"): NovaEvent {
  return {
    id: `${Date.now()}-${Math.random().toString(16).slice(2)}`,
    type,
    label,
    detail,
    time: "ahora",
    accent,
  };
}

export function readLocal<T>(key: string, fallback: T): T {
  try {
    const raw = localStorage.getItem(key);
    return raw ? (JSON.parse(raw) as T) : fallback;
  } catch {
    return fallback;
  }
}

export function writeLocal<T>(key: string, value: T) {
  try {
    localStorage.setItem(key, JSON.stringify(value));
  } catch {
    // Preview can run with storage disabled; memory remains session-local.
  }
}
