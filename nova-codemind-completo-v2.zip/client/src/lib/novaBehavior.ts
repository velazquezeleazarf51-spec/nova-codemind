import type { Expression } from "./novaState";

export type NovaIntent =
  | "idle"
  | "listening"
  | "thinking"
  | "speaking"
  | "greeting"
  | "touch_reaction"
  | "walking"
  | "resting";

export interface NovaBehaviorState {
  emotion: Expression;
  intent: NovaIntent;
  speaking: boolean;
  lookAtUser: boolean;
  energy: number;
  updatedAt: number;
}

export const initialNovaBehavior: NovaBehaviorState = {
  emotion: "feliz",
  intent: "idle",
  speaking: false,
  lookAtUser: true,
  energy: 0.72,
  updatedAt: Date.now(),
};

export function behaviorFromReply(reply: string, emotion: Expression): NovaBehaviorState {
  const lower = reply.toLowerCase();
  const intent: NovaIntent = /\b(?:hola|bienvenid[oa])\b/.test(lower)
    ? "greeting"
    : /\b(?:pausa|límite)\b/.test(lower)
      ? "resting"
      : "speaking";
  return {
    emotion,
    intent,
    speaking: true,
    lookAtUser: true,
    energy: emotion === "dormida" ? 0.22 : emotion === "seria" ? 0.52 : 0.78,
    updatedAt: Date.now(),
  };
}

export function stopSpeaking(state: NovaBehaviorState): NovaBehaviorState {
  return { ...state, intent: "idle", speaking: false, updatedAt: Date.now() };
}

/** Expresión sugerida a partir del texto de la respuesta de Nova. */
export function inferExpression(text: string): Expression {
  const lower = text.toLowerCase();
  if (/\b(?:pausa|límite|detente)\b/.test(lower)) return "seria";
  if (/\b(?:gracias|hola)\b/.test(lower) || lower.includes("me alegra")) return "feliz";
  if (lower.includes("pregunta") || lower.includes("explor")) return "curiosa";
  return "pensativa";
}
