import { CHAT_MAX_CONTEXT_MESSAGES, CHAT_MAX_MESSAGE_LENGTH } from "@shared/nova";

export interface HistoryMessage {
  from: "nova" | "user";
  text: string;
  /** Mensajes solo de interfaz (bienvenida, errores): se muestran pero nunca se envían al modelo. */
  local?: boolean;
}

export interface LlmMessage {
  role: "user" | "assistant";
  content: string;
}

/**
 * Convierte el historial visible en el contexto que se envía al modelo:
 * descarta mensajes locales, recorta a los últimos `max` mensajes,
 * limita la longitud de cada uno y garantiza que empiece con un mensaje del usuario.
 */
export function buildConversation(messages: HistoryMessage[], max = CHAT_MAX_CONTEXT_MESSAGES): LlmMessage[] {
  const mapped: LlmMessage[] = messages
    .filter(message => !message.local)
    .map(message => ({
      role: message.from === "nova" ? ("assistant" as const) : ("user" as const),
      content: message.text.trim().slice(0, CHAT_MAX_MESSAGE_LENGTH),
    }))
    .filter(message => message.content.length > 0);

  const recent = mapped.slice(-max);
  while (recent.length > 0 && recent[0].role !== "user") recent.shift();
  return recent;
}
