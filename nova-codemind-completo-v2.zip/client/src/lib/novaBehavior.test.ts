import { describe, expect, it } from "vitest";
import { behaviorFromReply, inferExpression, stopSpeaking } from "./novaBehavior";

describe("inferExpression", () => {
  it("marca seriedad ante pausa, límite o detente", () => {
    expect(inferExpression("Hagamos una pausa.")).toBe("seria");
    expect(inferExpression("Ese es mi límite.")).toBe("seria");
    expect(inferExpression("Me detengo: detente aquí")).toBe("seria");
  });

  it("no confunde palabras que solo contienen 'hola'", () => {
    expect(inferExpression("La ahola no existe")).toBe("pensativa");
    expect(inferExpression("Hola, ¿cómo estás?")).toBe("feliz");
  });

  it("detecta curiosidad y usa pensativa por defecto", () => {
    expect(inferExpression("Quiero explorar eso")).toBe("curiosa");
    expect(inferExpression("Puede ser.")).toBe("pensativa");
  });
});

describe("behaviorFromReply / stopSpeaking", () => {
  it("saluda solo con la palabra completa", () => {
    expect(behaviorFromReply("Hola, qué bueno verte", "feliz").intent).toBe("greeting");
    expect(behaviorFromReply("Parece un cascabel ahola", "feliz").intent).toBe("speaking");
  });

  it("entra en reposo ante una pausa o un límite", () => {
    expect(behaviorFromReply("Necesito una pausa", "seria").intent).toBe("resting");
  });

  it("baja la energía cuando está dormida o seria", () => {
    expect(behaviorFromReply("zzz", "dormida").energy).toBeLessThan(behaviorFromReply("ok", "feliz").energy);
  });

  it("stopSpeaking deja de hablar y vuelve a idle", () => {
    const stopped = stopSpeaking(behaviorFromReply("Hola", "feliz"));
    expect(stopped.speaking).toBe(false);
    expect(stopped.intent).toBe("idle");
  });
});
