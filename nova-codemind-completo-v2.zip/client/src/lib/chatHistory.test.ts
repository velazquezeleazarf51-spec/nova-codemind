import { describe, expect, it } from "vitest";
import { buildConversation, type HistoryMessage } from "./chatHistory";
import { CHAT_MAX_CONTEXT_MESSAGES, CHAT_MAX_MESSAGES_PER_REQUEST, CHAT_MAX_MESSAGE_LENGTH } from "@shared/nova";

const turn = (i: number): HistoryMessage[] => [
  { from: "user", text: `pregunta ${i}` },
  { from: "nova", text: `respuesta ${i}` },
];

describe("buildConversation", () => {
  it("nunca envía mensajes locales (bienvenida, errores)", () => {
    const result = buildConversation([
      { from: "nova", text: "Estoy en línea", local: true },
      { from: "user", text: "hola" },
      { from: "nova", text: "No puedo alcanzar el modelo", local: true },
      { from: "user", text: "¿sigues ahí?" },
    ]);
    expect(result).toEqual([
      { role: "user", content: "hola" },
      { role: "user", content: "¿sigues ahí?" },
    ]);
  });

  it("recorta una conversación larga sin superar el límite del servidor", () => {
    const history = Array.from({ length: 50 }, (_, i) => turn(i)).flat();
    const result = buildConversation(history);
    expect(result.length).toBeLessThanOrEqual(CHAT_MAX_CONTEXT_MESSAGES);
    expect(CHAT_MAX_CONTEXT_MESSAGES).toBeLessThanOrEqual(CHAT_MAX_MESSAGES_PER_REQUEST);
    expect(result.at(-1)).toEqual({ role: "assistant", content: "respuesta 49" });
  });

  it("conserva el mensaje más reciente y empieza siempre con el usuario", () => {
    const history = [...Array.from({ length: 12 }, (_, i) => turn(i)).flat(), { from: "user" as const, text: "último" }];
    const result = buildConversation(history, 5);
    expect(result[0].role).toBe("user");
    expect(result.at(-1)).toEqual({ role: "user", content: "último" });
  });

  it("recorta mensajes demasiado largos y descarta los vacíos", () => {
    const result = buildConversation([
      { from: "user", text: "x".repeat(CHAT_MAX_MESSAGE_LENGTH + 500) },
      { from: "nova", text: "   " },
    ]);
    expect(result).toHaveLength(1);
    expect(result[0].content).toHaveLength(CHAT_MAX_MESSAGE_LENGTH);
  });

  it("el décimo mensaje del usuario ya no rompe el chat (regresión)", () => {
    const history: HistoryMessage[] = [{ from: "nova", text: "bienvenida", local: true }];
    for (let i = 0; i < 10; i++) history.push(...turn(i));
    history.push({ from: "user", text: "mensaje 11" });
    expect(buildConversation(history).length).toBeLessThanOrEqual(CHAT_MAX_MESSAGES_PER_REQUEST);
  });
});
