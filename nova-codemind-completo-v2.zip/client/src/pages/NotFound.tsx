import { AlertCircle, Home } from "lucide-react";
import { useEffect } from "react";
import { useLocation } from "wouter";

const NOT_FOUND_PATH = "/404";

export default function NotFound() {
  const [, setLocation] = useLocation();
  useEffect(() => {
    const robots = document.createElement("meta");
    robots.name = "robots";
    robots.content = "noindex";
    document.head.appendChild(robots);
    if (window.location.pathname.replace(/\/$/, "") !== NOT_FOUND_PATH) window.location.replace(NOT_FOUND_PATH);
    return () => robots.remove();
  }, []);

  return <div style={{ minHeight: "100vh", display: "grid", placeItems: "center", background: "#070817", color: "#f4f1ff", padding: 20 }}>
    <div style={{ width: "min(440px, 100%)", textAlign: "center", border: "1px solid rgba(132,143,212,.2)", borderRadius: 20, padding: "46px 28px", background: "linear-gradient(145deg, rgba(21,24,53,.92), rgba(9,11,28,.92))" }}>
      <div style={{ width: 64, height: 64, display: "grid", placeItems: "center", margin: "0 auto 22px", borderRadius: "50%", color: "#ff4fd8", border: "1px solid rgba(255,79,216,.35)", boxShadow: "0 0 28px rgba(255,79,216,.18)" }}><AlertCircle size={32} /></div>
      <div style={{ color: "#5ce1ff", fontSize: 11, letterSpacing: ".18em", fontWeight: 800 }}>SEÑAL NO ENCONTRADA</div>
      <h1 style={{ fontSize: 54, lineHeight: 1, margin: "14px 0 8px", fontFamily: "Space Grotesk, sans-serif" }}>404</h1>
      <h2 style={{ fontSize: 18, margin: "0 0 12px" }}>Esta ruta no existe</h2>
      <p style={{ color: "#9296bc", fontSize: 12, lineHeight: 1.6, margin: "0 auto 25px", maxWidth: 300 }}>Nova no encontró la coordenada solicitada. Regresa a la cabina para continuar.</p>
      <button onClick={() => setLocation("/")} style={{ border: 0, borderRadius: 9, background: "#ff4fd8", color: "#240a26", fontWeight: 800, fontSize: 11, padding: "11px 16px", cursor: "pointer", display: "inline-flex", alignItems: "center", gap: 7 }}><Home size={15} /> Volver a la cabina</button>
    </div>
  </div>;
}
