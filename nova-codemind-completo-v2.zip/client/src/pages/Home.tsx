import { useMemo, useState } from "react";
import { Activity, Bell, Brain, ChevronDown, CircleDot, Command, Eye, Gauge, Heart, History, Menu, MessageCircle, MoreHorizontal, Move3d, PanelRight, Radio, Settings2, ShieldCheck, Sparkles, Touchpad, Volume2, Waves, X, Zap } from "lucide-react";
import NovaScene from "@/components/nova/NovaScene";
import ChatPanel from "@/components/nova/ChatPanel";
import MemoryPanel from "@/components/nova/MemoryPanel";
import ControlPanel from "@/components/nova/ControlPanel";
import { initialNovaBehavior, type NovaBehaviorState } from "@/lib/novaBehavior";
import { autonomyLabels, expressionLabels, initialEvents, initialMemories, makeEvent, readLocal, touchProfiles, writeLocal, type AutonomyMode, type Expression, type MemoryItem, type NovaEvent, type TouchZone } from "@/lib/novaState";

const touchLabels: Record<TouchZone, string> = { cabeza: "cabeza", cabello: "cabello", hombros: "hombros", manos: "manos", cuerpo: "cintura / cuerpo", piernas: "piernas / botas" };

type Tab = "cabina" | "memoria" | "controles" | "actividad";
const NOVA_WEBHOOK_URL = "https://api.manus.im/api/webhook/triggers/960bcb91-4364-46c6-ad82-46f469176ec2";

export default function Home() {
  const [activeTab, setActiveTab] = useState<Tab>("cabina");
  const [mode, setMode] = useState<AutonomyMode>(() => readLocal("nova-mode", "companera"));
  const [expression, setExpression] = useState<Expression>("feliz");
  const [gravity, setGravity] = useState(1);
  const [sensitivity, setSensitivity] = useState(1);
  const [paused, setPaused] = useState(false);
  const [physicsState, setPhysicsState] = useState("Apoyada · 1.0 g");
  const [memories, setMemories] = useState<MemoryItem[]>(() => readLocal("nova-memories", initialMemories));
  const [events, setEvents] = useState<NovaEvent[]>(initialEvents);
  const [mobileMenu, setMobileMenu] = useState(false);
  const [toast, setToast] = useState("");
  const [behavior, setBehavior] = useState<NovaBehaviorState>(initialNovaBehavior);

  const activeMemoryCount = useMemo(() => memories.filter(memory => memory.status === "confirmada").length, [memories]);
  const emitWebhook = (type: string, label: string, detail: string) => {
    const safeDetail = type === "chat" ? "Mensaje recibido en la sesión" : detail;
    void fetch(NOVA_WEBHOOK_URL, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ event: type, label, detail: safeDetail, source: "codemind-nova", sent_at: new Date().toISOString() }) }).catch(() => undefined);
  };
  const updateMode = (next: AutonomyMode) => { setMode(next); writeLocal("nova-mode", next); addEvent("Modo actualizado", `Nova ahora trabaja como ${autonomyLabels[next].toLowerCase()}`, "autonomía", "pink"); };
  const addEvent = (label: string, detail: string, type: string, accent: NovaEvent["accent"] = "cyan") => { setEvents(current => [makeEvent(label, detail, type, accent), ...current].slice(0, 8)); emitWebhook(type, label, detail); };
  const handleTouch = (zone: TouchZone) => { const profile = touchProfiles[zone]; setExpression(profile.expression); setBehavior({ emotion: profile.expression, intent: "touch_reaction", speaking: false, lookAtUser: true, energy: profile.consent === "confirmar" ? 0.38 : 0.72, updatedAt: Date.now() }); const detail = profile.consent === "confirmar" ? `Zona sensible: ${profile.label} · Nova marca un límite y espera confirmación` : `Zona: ${profile.label} · ${profile.response}`; addEvent("Interacción táctil", detail, "tacto", "purple"); flash(profile.consent === "confirmar" ? `Nova pide consentimiento antes de intensificar ${profile.label.toLowerCase()}` : `Nova ${profile.response}`); };
  const handleUserEvent = (text: string) => { addEvent("Mensaje recibido", text.length > 46 ? `${text.slice(0, 46)}…` : text, "chat", "cyan"); };
  const confirmMemory = (id: string) => { setMemories(current => { const next = current.map(item => item.id === id ? { ...item, status: "confirmada" as const } : item); writeLocal("nova-memories", next); return next; }); addEvent("Memoria confirmada", "Una preferencia pasó a formar parte de Nova", "memoria", "pink"); flash("Memoria guardada bajo tu control"); };
  const deleteMemory = (id: string) => { setMemories(current => { const next = current.filter(item => item.id !== id); writeLocal("nova-memories", next); return next; }); addEvent("Memoria eliminada", "Nova olvidó el patrón seleccionado", "memoria", "yellow"); flash("Memoria eliminada"); };
  const flash = (message: string) => { setToast(message); window.setTimeout(() => setToast(""), 2600); };
  const changeExpression = (next: Expression) => { setExpression(next); addEvent("Expresión cambiada", `Estado visual: ${expressionLabels[next]}`, "expresión", "pink"); };
  const navItems: { id: Tab; label: string; icon: typeof Command; badge?: string }[] = [
    { id: "cabina", label: "Cabina 3D", icon: Move3d },
    { id: "memoria", label: "Memoria", icon: Brain, badge: `${activeMemoryCount}` },
    { id: "controles", label: "Controles", icon: Settings2 },
    { id: "actividad", label: "Actividad", icon: History },
  ];

  return <div className="nova-app">
    <div className="ambient ambient-one" /><div className="ambient ambient-two" />
    <header className="topbar"><button className="mobile-menu-button" onClick={() => setMobileMenu(current => !current)} aria-label="Abrir menú">{mobileMenu ? <X size={18} /> : <Menu size={18} />}</button><div className="brand"><span className="brand-orbit"><Sparkles size={15} /></span><span><strong>CodeMind</strong><em>NOVA</em></span></div><div className="topbar-center"><span className="topbar-kicker"><CircleDot size={12} /> LIVE COMPANION SYSTEM</span><span className="topbar-divider" /><span className="topbar-location">SECTOR 07 / PERSONAL SPACE</span></div><div className="topbar-actions"><button className="top-icon" aria-label="Notificaciones"><Bell size={16} /><i /></button><span className="status-chip"><i /> Sistema estable</span><div className="user-chip"><span className="user-initial">A</span><span>Anthony</span><ChevronDown size={13} /></div></div></header>
    <div className={`app-body ${mobileMenu ? "menu-open" : ""}`}>
      <aside className="sidebar"><div className="sidebar-label">NAVEGACIÓN</div><nav>{navItems.map(item => <button key={item.id} className={activeTab === item.id ? "active" : ""} onClick={() => { setActiveTab(item.id); setMobileMenu(false); }}><item.icon size={17} /><span>{item.label}</span>{item.badge && <b>{item.badge}</b>}</button>)}</nav><div className="sidebar-divider" /><div className="sidebar-label">SISTEMA</div><button className="side-link" onClick={() => flash("Webhook Nova conectado y listo para recibir eventos")}><Radio size={17} /><span>Webhook Nova</span><i className="connection-dot" /></button><button className="side-link" onClick={() => flash("Límites de privacidad activos")}><ShieldCheck size={17} /><span>Límites y privacidad</span></button><div className="sidebar-bottom"><div className="sidebar-micro"><Waves size={14} /><span><strong>Aprendizaje activo</strong><small>último patrón · hace 4 min</small></span></div><button className="sidebar-profile"><span className="user-initial small">A</span><span><strong>Anthony</strong><small>Cuenta personal</small></span><MoreHorizontal size={16} /></button></div></aside>
      <main className="workspace">
        <div className="workspace-heading"><div><span className="eyebrow"><Command size={13} /> SALA PERSONAL</span><h1>{activeTab === "cabina" ? "Tu espacio con Nova" : activeTab === "memoria" ? "Memoria con criterio" : activeTab === "controles" ? "Diseña su comportamiento" : "Rastro de actividad"}</h1><p>{activeTab === "cabina" ? "Una compañera visible, expresiva y atenta a tus ritmos." : activeTab === "memoria" ? "Observa patrones. Tú decides qué se queda." : activeTab === "controles" ? "Autonomía, física y límites que siempre puedes ajustar." : "Todo lo que Nova ha hecho, explicado de forma legible."}</p></div><div className="workspace-heading-actions"><button className="outline-button"><Eye size={15} /> Vista inmersiva</button><button className="pink-button"><Sparkles size={15} /> Personalizar</button></div></div>
        {activeTab === "cabina" && <div className="cockpit-grid"><section className="scene-card panel-glass"><div className="scene-toolbar"><div className="scene-toolbar-left"><span className="eyebrow"><Move3d size={13} /> NOVA / 3D SPACE</span><span className="scene-live"><i /> Física en tiempo real</span></div><div className="scene-toolbar-right"><span className="scene-stat"><Gauge size={13} /> {physicsState}</span><button className="icon-button" aria-label="Sonido"><Volume2 size={15} /></button><button className="icon-button" aria-label="Más opciones"><MoreHorizontal size={15} /></button></div></div><div className={`scene-viewport ${paused ? "scene-paused" : ""}`}><NovaScene gravity={gravity} expression={expression} behavior={behavior} sensitivity={sensitivity} onTouch={handleTouch} onPhysics={value => setPhysicsState(value)} /><div className="scene-scanline" /><div className="scene-tag scene-tag-left"><span>ROOT / PHYSICS</span><strong>0.00 m/s</strong></div><div className="scene-tag scene-tag-right"><span>EXPRESSION</span><strong>{expressionLabels[expression]}</strong></div><div className="gravity-readout"><span className="gravity-ring"><Gauge size={13} /></span><span><strong>{gravity.toFixed(1)} g</strong><small>gravedad</small></span></div><div className="touch-hint"><Touchpad size={13} /> toca una zona para una reacción</div></div><div className="scene-footer"><div className="scene-footer-item"><span className="footer-dot pink" /><span><small>Modelo</small><strong>Nova / Cyber-goth</strong></span></div><div className="scene-footer-item"><span className="footer-dot cyan" /><span><small>Estado</small><strong>{paused ? "En pausa" : "Presente y atenta"}</strong></span></div><div className="scene-footer-item"><span className="footer-dot yellow" /><span><small>Interacción</small><strong>Ratón + tacto</strong></span></div><button className="scene-footer-button" onClick={() => setPaused(current => !current)}>{paused ? "Reanudar" : "Pausar escena"}</button></div></section><div className="right-rail"><ChatPanel expression={expression} autonomy={mode} onExpression={changeExpression} onBehavior={setBehavior} onUserEvent={handleUserEvent} /></div></div>}
        {activeTab === "memoria" && <div className="wide-panel"><MemoryPanel memories={memories} onConfirm={confirmMemory} onDelete={deleteMemory} /></div>}
        {activeTab === "controles" && <div className="wide-panel"><ControlPanel mode={mode} expression={expression} gravity={gravity} sensitivity={sensitivity} paused={paused} onMode={updateMode} onExpression={changeExpression} onGravity={value => { setGravity(value); setPhysicsState(`${paused ? "En pausa" : "Apoyada"} · ${value.toFixed(1)} g`); }} onSensitivity={setSensitivity} onPause={() => setPaused(current => !current)} /></div>}
        {activeTab === "actividad" && <div className="activity-layout"><section className="activity-panel panel-glass"><div className="panel-heading"><div><span className="eyebrow"><Activity size={13} /> EVENT STREAM</span><h2>Actividad reciente</h2></div><button className="outline-button compact"><Bell size={13} /> Solo importantes</button></div><div className="event-list">{events.map(event => <article key={event.id} className="event-row"><span className={`event-icon ${event.accent}`}><Activity size={14} /></span><div><strong>{event.label}</strong><p>{event.detail}</p></div><time>{event.time}</time><span className="event-type">{event.type}</span></article>)}</div></section><ControlPanel mode={mode} expression={expression} gravity={gravity} sensitivity={sensitivity} paused={paused} onMode={updateMode} onExpression={changeExpression} onGravity={setGravity} onSensitivity={setSensitivity} onPause={() => setPaused(current => !current)} /></div>}
      </main>
    </div>
    <div className="bottom-status"><span><span className="signal-bars"><i /><i /><i /></span> Conexión segura</span><span><span className="bottom-sep" /> WEBHOOK READY</span><span><span className="bottom-sep" /> MEMORIA LOCAL · {activeMemoryCount} CONFIRMADAS</span><span className="bottom-status-right"><Zap size={12} /> Nova adapta, tú decides</span></div>
    {toast && <div className="toast"><Sparkles size={15} /> {toast}</div>}
  </div>;
}
