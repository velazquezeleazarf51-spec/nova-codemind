import { useEffect, useState } from "react";
import { Bot, Heart, Mic2, Send, Sparkles, Volume2 } from "lucide-react";
import { trpc } from "@/lib/trpc";
import { expressionEmoji, type AutonomyMode, type Expression } from "@/lib/novaState";
import { behaviorFromReply, inferExpression, stopSpeaking, type NovaBehaviorState } from "@/lib/novaBehavior";
import { buildConversation } from "@/lib/chatHistory";

interface ChatMessage { id: string; from: "nova" | "user"; text: string; time: string; local?: boolean; }
interface ChatPanelProps { expression: Expression; autonomy?: AutonomyMode; onExpression: (expression: Expression) => void; onBehavior: (behavior: NovaBehaviorState) => void; onUserEvent: (text: string) => void; }

const formatTime = (date = new Date()) => date.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
const quickReplies = ["¿Qué aprendiste hoy?", "Haz una pausa conmigo", "Muéstrame tus controles"];

export default function ChatPanel({ expression, autonomy = "autonoma", onExpression, onBehavior, onUserEvent }: ChatPanelProps) {
  // Los mensajes `local` solo se muestran en pantalla; nunca se envían al modelo.
  const [messages, setMessages] = useState<ChatMessage[]>(() => [
    { id: "1", from: "nova", text: "Estoy en línea. Puedo aprender tus ritmos, pero tú decides qué se queda conmigo.", time: formatTime(), local: true },
    { id: "2", from: "nova", text: "Mueve la cámara o toca una zona. La gravedad está activa y mis reacciones también.", time: formatTime(), local: true },
  ]);
  const [draft, setDraft] = useState("");
  const chatMutation = trpc.nova.chat.useMutation();

  useEffect(() => () => {
    if (typeof window !== "undefined" && "speechSynthesis" in window) window.speechSynthesis.cancel();
  }, []);

  const speak = (text: string, emotion: Expression = expression) => {
    onBehavior(behaviorFromReply(text, emotion));
    if (typeof window === "undefined" || !("speechSynthesis" in window)) {
      globalThis.setTimeout(() => onBehavior(stopSpeaking(behaviorFromReply(text, emotion))), 1200);
      return;
    }
    window.speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.lang = "es-MX";
    utterance.rate = 0.96;
    utterance.pitch = 1.08;
    utterance.onend = () => onBehavior(stopSpeaking(behaviorFromReply(text, emotion)));
    utterance.onerror = () => onBehavior(stopSpeaking(behaviorFromReply(text, emotion)));
    window.speechSynthesis.speak(utterance);
  };

  const playVoiceSample = () => {
    const audio = new Audio("/audio/nova-voice-intro.wav");
    void audio.play().catch(() => speak("Hola, soy Nova. Estoy aquí contigo, atenta y presente.", expression));
  };

  const respond = (text: string) => {
    const clean = text.trim();
    if (!clean) return;
    onUserEvent(clean);
    const userMessage: ChatMessage = { id: `${Date.now()}-u`, from: "user", text: clean, time: formatTime() };
    const conversation = buildConversation([...messages, userMessage]);
    setMessages(current => [...current, userMessage]);
    setDraft("");
    chatMutation.mutate({ messages: conversation, autonomy }, {
      onSuccess: ({ reply }) => {
        const nextExpression = inferExpression(reply);
        const novaMessage: ChatMessage = { id: `${Date.now()}-n`, from: "nova", text: reply, time: formatTime() };
        setMessages(current => [...current, novaMessage]);
        onExpression(nextExpression);
        onBehavior(behaviorFromReply(reply, nextExpression));
        speak(reply, nextExpression);
      },
      onError: error => {
        const fallback = error.data?.code === "TOO_MANY_REQUESTS"
          ? error.message
          : "No puedo alcanzar el modelo ahora. Mantengo la sesión segura y puedo seguir reaccionando localmente; revisa la conexión del servidor.";
        setMessages(current => [...current, { id: `${Date.now()}-n`, from: "nova", text: fallback, time: formatTime(), local: true }]);
        onExpression("seria");
        onBehavior({ emotion: "seria", intent: "listening", speaking: false, lookAtUser: true, energy: 0.45, updatedAt: Date.now() });
      },
    });
  };

  return <section className="chat-panel panel-glass">
    <div className="panel-heading"><div><span className="eyebrow"><Bot size={13} /> CANAL NOVA</span><h2>Habla conmigo</h2></div><span className="live-dot"><i /> IA EN LÍNEA</span></div>
    <div className="chat-status"><span className="nova-avatar">{expressionEmoji[expression]}</span><div><strong>Nova</strong><small>{chatMutation.isPending ? "está pensando…" : `responde con ${expression}`}</small></div><button className="icon-button" aria-label="Escuchar la voz de Nova" title="Escuchar voz de Nova" onClick={playVoiceSample}><Volume2 size={16} /></button></div>
    <div className="chat-messages" aria-live="polite">
      {messages.map(message => <div key={message.id} className={`message-row ${message.from}`}><div className="message-bubble">{message.from === "nova" && <span className="bubble-mark"><Sparkles size={11} /></span>}{message.text}<time>{message.time}</time></div></div>)}
    </div>
    <div className="quick-replies">{quickReplies.map(reply => <button key={reply} onClick={() => respond(reply)}>{reply}</button>)}</div>
    <form className="chat-input" onSubmit={event => { event.preventDefault(); respond(draft); }}><button type="button" className="input-tool" aria-label="Probar voz" title="Probar voz" onClick={() => speak("Te escucho. Dime qué necesitas.", expression)}><Mic2 size={16} /></button><input value={draft} onChange={event => setDraft(event.target.value)} placeholder={chatMutation.isPending ? "Nova está pensando…" : "Escribe algo para Nova…"} aria-label="Mensaje para Nova" disabled={chatMutation.isPending} /><button type="submit" className="send-button" aria-label="Enviar mensaje" disabled={chatMutation.isPending}><Send size={16} /></button></form>
    <div className="chat-footer"><span><Heart size={12} /> Memoria bajo tu control</span><span>GPT-5 mini · voz dinámica</span></div>
  </section>;
}
