import { useEffect, useRef } from "react";
import * as THREE from "three";
import { OrbitControls } from "three/examples/jsm/controls/OrbitControls.js";
import { GLTFLoader } from "three/examples/jsm/loaders/GLTFLoader.js";
import type { Expression, TouchZone } from "@/lib/novaState";
import type { NovaBehaviorState } from "@/lib/novaBehavior";

interface NovaSceneProps {
  gravity: number;
  expression: Expression;
  behavior: NovaBehaviorState;
  sensitivity: number;
  onTouch: (zone: TouchZone) => void;
  onPhysics: (value: string) => void;
}

const MAGENTA = 0xff4fd8;
const CYAN = 0x5ce1ff;

function material(color: number, roughness = 0.44, metalness = 0.22) {
  return new THREE.MeshStandardMaterial({ color, roughness, metalness, emissive: color === MAGENTA ? 0x2b0828 : 0x050a18, emissiveIntensity: color === MAGENTA ? 0.34 : 0.2 });
}

function makeProceduralNova() {
  const group = new THREE.Group();
  group.name = "NovaProceduralFallback";
  const skin = material(0xffc3ad, 0.62, 0.04);
  const black = material(0x151224, 0.3, 0.54);
  const magenta = material(MAGENTA, 0.26, 0.48);
  const hair = material(0xe9ad84, 0.38, 0.16);
  const face = new THREE.Mesh(new THREE.SphereGeometry(0.46, 28, 24), skin);
  face.position.y = 2.12;
  face.scale.set(0.86, 1.07, 0.84);
  group.add(face);

  const torso = new THREE.Mesh(new THREE.CapsuleGeometry(0.56, 0.84, 8, 18), black);
  torso.position.y = 1.05;
  torso.scale.set(0.88, 1, 0.58);
  group.add(torso);

  const collar = new THREE.Mesh(new THREE.TorusGeometry(0.27, 0.035, 8, 28), magenta);
  collar.rotation.x = Math.PI / 2;
  collar.position.set(0, 1.68, 0.02);
  group.add(collar);

  const belt = new THREE.Mesh(new THREE.TorusGeometry(0.45, 0.055, 8, 32), magenta);
  belt.rotation.x = Math.PI / 2;
  belt.position.y = 0.55;
  belt.scale.z = 0.76;
  group.add(belt);

  const skirt = new THREE.Mesh(new THREE.CylinderGeometry(0.7, 0.84, 0.42, 10), black);
  skirt.position.y = 0.38;
  skirt.scale.z = 0.62;
  group.add(skirt);

  const legGeo = new THREE.CapsuleGeometry(0.17, 0.92, 6, 14);
  const bootGeo = new THREE.CapsuleGeometry(0.23, 0.58, 6, 14);
  for (const x of [-0.29, 0.29]) {
    const leg = new THREE.Mesh(legGeo, skin);
    leg.position.set(x, -0.35, 0);
    group.add(leg);
    const boot = new THREE.Mesh(bootGeo, black);
    boot.position.set(x, -1.1, 0.02);
    boot.scale.z = 0.86;
    group.add(boot);
  }

  for (const x of [-0.68, 0.68]) {
    const arm = new THREE.Mesh(new THREE.CapsuleGeometry(0.13, 0.7, 6, 12), black);
    arm.position.set(x, 1.08, 0);
    arm.rotation.z = x < 0 ? -0.18 : 0.18;
    group.add(arm);
    const hand = new THREE.Mesh(new THREE.SphereGeometry(0.15, 16, 12), skin);
    hand.position.set(x * 1.04, 0.64, 0);
    group.add(hand);
  }

  const ponytailGeo = new THREE.CapsuleGeometry(0.17, 0.92, 6, 14);
  for (const x of [-0.42, 0.42]) {
    const pony = new THREE.Mesh(ponytailGeo, hair);
    pony.position.set(x, 1.75, -0.2);
    pony.rotation.z = x < 0 ? -0.35 : 0.35;
    group.add(pony);
  }
  const fringe = new THREE.Mesh(new THREE.SphereGeometry(0.52, 20, 12), hair);
  fringe.position.set(0, 2.35, -0.03);
  fringe.scale.set(1, 0.52, 0.7);
  group.add(fringe);

  const eyeGeo = new THREE.SphereGeometry(0.055, 12, 8);
  for (const x of [-0.17, 0.17]) {
    const eye = new THREE.Mesh(eyeGeo, magenta);
    eye.position.set(x, 2.12, 0.41);
    group.add(eye);
  }

  const heart = new THREE.Mesh(new THREE.OctahedronGeometry(0.1), magenta);
  heart.position.set(0, 1.18, 0.48);
  heart.rotation.z = Math.PI / 4;
  group.add(heart);
  return group;
}

function roomMaterial(color: number, roughness = 0.7, metalness = 0.12, emissive = 0x000000) {
  return new THREE.MeshStandardMaterial({ color, roughness, metalness, emissive, emissiveIntensity: emissive ? 1.4 : 0 });
}

function makeNovaRoom() {
  const room = new THREE.Group();
  room.name = "NovaCyberRoom";
  const floorMat = roomMaterial(0x10142b, 0.86, 0.25);
  const wallMat = roomMaterial(0x0d1021, 0.9, 0.1);
  const pinkMat = roomMaterial(MAGENTA, 0.35, 0.35, 0x4a0d4b);
  const cyanMat = roomMaterial(CYAN, 0.28, 0.25, 0x0b4054);
  const softMat = roomMaterial(0x34214a, 0.78, 0.05);
  const addBox = (name: string, size: [number, number, number], position: [number, number, number], mat: THREE.Material, cast = false) => {
    const mesh = new THREE.Mesh(new THREE.BoxGeometry(...size), mat);
    mesh.name = name;
    mesh.position.set(...position);
    mesh.castShadow = cast;
    mesh.receiveShadow = true;
    room.add(mesh);
    return mesh;
  };

  addBox("room-floor", [11, 0.18, 8], [0, -0.12, 0], floorMat);
  addBox("room-back-wall", [11, 5.2, 0.16], [0, 2.5, -3.9], wallMat);
  addBox("room-left-wall", [0.16, 5.2, 8], [-5.45, 2.5, 0], wallMat);
  addBox("room-right-wall", [0.16, 5.2, 8], [5.45, 2.5, 0], wallMat);
  addBox("ceiling-strip", [10.6, 0.08, 7.6], [0, 5.08, 0], roomMaterial(0x171936, 0.9, 0.05));

  // Cama de Nova: un bloque bajo, almohada y tira de luz magenta.
  addBox("bed-base", [2.35, 0.38, 1.55], [-3.55, 0.28, -2.45], roomMaterial(0x171326, 0.58, 0.32), true);
  addBox("bed-mattress", [2.18, 0.22, 1.42], [-3.55, 0.58, -2.45], softMat, true);
  addBox("bed-pillow", [0.58, 0.14, 0.92], [-4.15, 0.78, -2.45], roomMaterial(0x8d5aa4, 0.74, 0.04), true);
  addBox("bed-neon", [2.1, 0.025, 0.035], [-3.55, 0.49, -3.23], pinkMat);

  // Escritorio, pantalla holográfica y luces de ambiente.
  addBox("desk-top", [2.45, 0.16, 0.85], [3.2, 1.28, -3.08], roomMaterial(0x17192e, 0.32, 0.55), true);
  addBox("desk-leg-left", [0.12, 1.25, 0.12], [2.2, 0.62, -3.08], wallMat, true);
  addBox("desk-leg-right", [0.12, 1.25, 0.12], [4.2, 0.62, -3.08], wallMat, true);
  addBox("holo-screen", [1.35, 0.78, 0.06], [3.2, 2.0, -3.42], cyanMat, true);
  addBox("screen-base", [0.12, 0.28, 0.12], [3.2, 1.57, -3.32], roomMaterial(0x252847, 0.3, 0.45), true);
  for (const x of [2.05, 4.35]) addBox("neon-bar", [0.035, 2.8, 0.035], [x, 2.25, -3.78], x < 3 ? cyanMat : pinkMat);

  // Ventana/panel trasero, estantería y pequeñas luces.
  addBox("window-frame", [2.2, 1.45, 0.05], [0, 3.05, -3.8], roomMaterial(0x202449, 0.35, 0.4), false);
  addBox("window-glow", [1.96, 1.2, 0.03], [0, 3.05, -3.74], roomMaterial(0x142b55, 0.32, 0.2, 0x123a6b));
  addBox("shelf", [1.7, 0.08, 0.34], [-1.1, 2.0, -3.63], roomMaterial(0x24203d, 0.55, 0.3), true);
  addBox("shelf-light", [1.45, 0.025, 0.03], [-1.1, 1.92, -3.82], pinkMat);
  for (const position of [[-1.7, 2.23, -3.55], [-0.85, 2.23, -3.55], [-0.25, 2.23, -3.55] ] as Array<[number, number, number]>) {
    const orb = new THREE.Mesh(new THREE.SphereGeometry(0.12, 14, 10), position[0] < -1 ? cyanMat : pinkMat);
    orb.position.set(...position);
    orb.castShadow = true;
    room.add(orb);
  }

  const rug = new THREE.Mesh(new THREE.CircleGeometry(2.45, 48), roomMaterial(0x171633, 0.95, 0.02));
  rug.rotation.x = -Math.PI / 2;
  rug.scale.y = 0.58;
  rug.position.set(0.25, -0.015, 0.3);
  rug.receiveShadow = true;
  room.add(rug);
  const rugLine = new THREE.Mesh(new THREE.RingGeometry(2.05, 2.08, 48), new THREE.MeshBasicMaterial({ color: MAGENTA, transparent: true, opacity: 0.42 }));
  rugLine.rotation.x = -Math.PI / 2;
  rugLine.scale.y = 0.58;
  rugLine.position.set(0.25, 0.005, 0.3);
  room.add(rugLine);
  return room;
}

export default function NovaScene({ gravity, expression, behavior, sensitivity, onTouch, onPhysics }: NovaSceneProps) {
  const mountRef = useRef<HTMLDivElement>(null);
  const expressionRef = useRef(expression);
  const gravityRef = useRef(gravity);
  const behaviorRef = useRef(behavior);
  const sensitivityRef = useRef(sensitivity);
  const onTouchRef = useRef(onTouch);
  const onPhysicsRef = useRef(onPhysics);

  useEffect(() => { expressionRef.current = expression; }, [expression]);
  useEffect(() => { gravityRef.current = gravity; }, [gravity]);
  useEffect(() => { behaviorRef.current = behavior; }, [behavior]);
  useEffect(() => { sensitivityRef.current = sensitivity; }, [sensitivity]);
  useEffect(() => { onTouchRef.current = onTouch; }, [onTouch]);
  useEffect(() => { onPhysicsRef.current = onPhysics; }, [onPhysics]);

  useEffect(() => {
    const mount = mountRef.current;
    if (!mount) return;
    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0x070817);
    scene.fog = new THREE.Fog(0x070817, 7, 18);

    const camera = new THREE.PerspectiveCamera(35, 1, 0.1, 100);
    camera.position.set(5.6, 3.4, 8.2);
    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: false, powerPreference: "high-performance" });
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    mount.appendChild(renderer.domElement);

    const controls = new OrbitControls(camera, renderer.domElement);
    controls.enableDamping = true;
    controls.dampingFactor = 0.08;
    controls.target.set(0, 1.1, 0);
    controls.minDistance = 3.2;
    controls.maxDistance = 15;
    controls.maxPolarAngle = Math.PI * 0.82;
    controls.minPolarAngle = Math.PI * 0.28;

    const ambient = new THREE.HemisphereLight(0x888cff, 0x100718, 1.6);
    scene.add(ambient);
    const key = new THREE.DirectionalLight(0xffd2f5, 2.4);
    key.position.set(3, 6, 4);
    key.castShadow = true;
    key.shadow.mapSize.set(1024, 1024);
    scene.add(key);
    const rim = new THREE.PointLight(CYAN, 4.2, 8, 2);
    rim.position.set(-3.5, 2.8, -1.5);
    scene.add(rim);
    const pink = new THREE.PointLight(MAGENTA, 3.8, 7, 2);
    pink.position.set(2.7, 1.2, 2.5);
    scene.add(pink);

    const room = makeNovaRoom();
    scene.add(room);
    const grid = new THREE.GridHelper(10, 28, 0x262b55, 0x14172c);
    grid.position.y = 0.012;
    (grid.material as THREE.Material).transparent = true;
    (grid.material as THREE.Material).opacity = 0.5;
    scene.add(grid);

    const root = new THREE.Group();
    root.position.set(0, 0, 0);
    scene.add(root);
    const fallback = makeProceduralNova();
    fallback.position.y = 1.12;
    fallback.traverse(object => { if (object instanceof THREE.Mesh) { object.castShadow = true; object.receiveShadow = true; } });
    root.add(fallback);

    const gravityRing = new THREE.Mesh(new THREE.TorusGeometry(1.05, 0.014, 8, 80), new THREE.MeshBasicMaterial({ color: MAGENTA, transparent: true, opacity: 0.8 }));
    gravityRing.rotation.x = Math.PI / 2;
    gravityRing.position.y = 0.035;
    root.add(gravityRing);
    const ring2 = new THREE.Mesh(new THREE.TorusGeometry(1.32, 0.008, 8, 80), new THREE.MeshBasicMaterial({ color: CYAN, transparent: true, opacity: 0.34 }));
    ring2.rotation.x = Math.PI / 2;
    ring2.position.y = 0.04;
    root.add(ring2);

    let loadedModel: THREE.Object3D | null = null;
    let loadedModelBaseY = 0.04;
    const modelYaw = -Math.PI / 2;
    let mixer: THREE.AnimationMixer | null = null;
    let activeAction: THREE.AnimationAction | null = null;
    let activeClipKey = "";
    let animationClips: THREE.AnimationClip[] = [];
    const mouthTargets: Array<{ mesh: THREE.Mesh; index: number }> = [];
    const blinkTargets: Array<{ mesh: THREE.Mesh; index: number }> = [];
    new GLTFLoader().load("/assets/nova-animated.glb", gltf => {
      loadedModel = gltf.scene;
      const modelBounds = new THREE.Box3().setFromObject(loadedModel);
      const modelSize = modelBounds.getSize(new THREE.Vector3());
      const fitScale = modelSize.y > 0 ? 3.18 / modelSize.y : 1.36;
      loadedModel.scale.setScalar(fitScale);
      const fittedBounds = new THREE.Box3().setFromObject(loadedModel);
      loadedModelBaseY = 0.04 - fittedBounds.min.y;
      loadedModel.position.y = loadedModelBaseY;
      loadedModel.rotation.y = modelYaw;
      loadedModel.traverse(object => {
        if (!(object instanceof THREE.Mesh)) return;
        object.castShadow = true;
        object.receiveShadow = true;
        if (!object.morphTargetDictionary || !object.morphTargetInfluences) return;
        Object.entries(object.morphTargetDictionary).forEach(([name, index]) => {
          if (/viseme|mouth|jaw|lip|open/i.test(name)) mouthTargets.push({ mesh: object, index });
          if (/blink|eye.?close|eyelid/i.test(name)) blinkTargets.push({ mesh: object, index });
        });
      });
      if (gltf.animations.length > 0) {
        animationClips = gltf.animations;
        mixer = new THREE.AnimationMixer(loadedModel);
        const firstClip = gltf.animations.find(clip => /idle|standing|relax/i.test(clip.name)) ?? gltf.animations[0];
        activeAction = mixer.clipAction(firstClip);
        activeAction.play();
        activeClipKey = firstClip.name;
      }
      root.add(loadedModel);
      root.remove(fallback);
    }, undefined, () => {
      // The procedural fallback is intentional while the model asset is absent.
    });

    const clock = new THREE.Clock();
    const velocity = new THREE.Vector3();
    const desired = new THREE.Vector3();
    const keys = new Set<string>();
    let dragging = false;
    let jumpRequested = false;
    let touchPulse = 0;
    let touchTilt = 0;
    let frame = 0;
    let disposed = false;
    let lastPhysicsState = "Estable";
    let manualUntil = 0;
    let wanderTimer = 1.8;

    const resize = () => {
      const width = mount.clientWidth || 720;
      const height = mount.clientHeight || 600;
      camera.aspect = width / height;
      camera.updateProjectionMatrix();
      renderer.setSize(width, height, false);
    };
    resize();
    const resizeObserver = new ResizeObserver(resize);
    resizeObserver.observe(mount);

    const onKeyDown = (event: KeyboardEvent) => {
      keys.add(event.key.toLowerCase());
      manualUntil = performance.now() + 6500;
      if (event.key === " ") jumpRequested = true;
      if (["arrowleft", "arrowright", "arrowup", "arrowdown", " "].includes(event.key.toLowerCase())) event.preventDefault();
    };
    const onKeyUp = (event: KeyboardEvent) => keys.delete(event.key.toLowerCase());
    window.addEventListener("keydown", onKeyDown, { passive: false });
    window.addEventListener("keyup", onKeyUp);

    const pickZone = (event: PointerEvent): TouchZone => {
      const rect = renderer.domElement.getBoundingClientRect();
      const x = (event.clientX - rect.left) / rect.width;
      const y = (event.clientY - rect.top) / rect.height;
      if (y < 0.34) return "cabeza";
      if (y < 0.49) return x < 0.38 || x > 0.62 ? "hombros" : "cabello";
      if (y < 0.68) return x < 0.4 || x > 0.6 ? "manos" : "cuerpo";
      return "piernas";
    };
    const onPointerDown = (event: PointerEvent) => {
      if (event.button !== 0) return;
      dragging = true;
      renderer.domElement.setPointerCapture(event.pointerId);
      onTouchRef.current(pickZone(event));
      touchPulse = 1;
      touchTilt = ((event.clientX / Math.max(window.innerWidth, 1)) - 0.5) * 0.08 * sensitivityRef.current;
      const rect = renderer.domElement.getBoundingClientRect();
      const x = (event.clientX - rect.left) / rect.width - 0.5;
      desired.x = THREE.MathUtils.clamp(x * 3.4 * sensitivityRef.current, -1.8, 1.8);
      const y = (event.clientY - rect.top) / rect.height - 0.5;
      desired.z = THREE.MathUtils.clamp(y * 4.8 * sensitivityRef.current, -2.7, 2.7);
      manualUntil = performance.now() + 5200;
    };
    const onPointerMove = (event: PointerEvent) => {
      if (!dragging) return;
      const rect = renderer.domElement.getBoundingClientRect();
      const x = (event.clientX - rect.left) / rect.width - 0.5;
      desired.x = THREE.MathUtils.clamp(x * 3.4 * sensitivityRef.current, -1.8, 1.8);
      const y = (event.clientY - rect.top) / rect.height - 0.5;
      desired.z = THREE.MathUtils.clamp(y * 4.8 * sensitivityRef.current, -2.7, 2.7);
      manualUntil = performance.now() + 5200;
      touchPulse = Math.min(1, touchPulse + 0.025);
    };
    const onPointerUp = (event: PointerEvent) => {
      dragging = false;
      if (renderer.domElement.hasPointerCapture(event.pointerId)) renderer.domElement.releasePointerCapture(event.pointerId);
    };
    renderer.domElement.addEventListener("pointerdown", onPointerDown);
    renderer.domElement.addEventListener("pointermove", onPointerMove);
    renderer.domElement.addEventListener("pointerup", onPointerUp);
    renderer.domElement.addEventListener("pointercancel", onPointerUp);

    const tick = () => {
      if (disposed) return;
      const delta = Math.min(clock.getDelta(), 0.05);
      const t = clock.elapsedTime;
      const currentBehavior = behaviorRef.current;
      frame += 1;
      const left = keys.has("arrowleft") || keys.has("a");
      const right = keys.has("arrowright") || keys.has("d");
      const forward = keys.has("arrowup") || keys.has("w");
      const back = keys.has("arrowdown") || keys.has("s");
      if (left) desired.x -= delta * 2.2 * sensitivityRef.current;
      if (right) desired.x += delta * 2.2 * sensitivityRef.current;
      if (forward) desired.z -= delta * 2.2 * sensitivityRef.current;
      if (back) desired.z += delta * 2.2 * sensitivityRef.current;
      if (performance.now() > manualUntil && !dragging && currentBehavior.intent !== "resting") {
        wanderTimer -= delta;
        if (wanderTimer <= 0) {
          desired.x = THREE.MathUtils.randFloat(-3.5, 3.5);
          desired.z = THREE.MathUtils.randFloat(-2.7, 2.7);
          wanderTimer = THREE.MathUtils.randFloat(3.8, 7.5);
        }
      }
      desired.x = THREE.MathUtils.clamp(desired.x, -4.1, 4.1);
      desired.z = THREE.MathUtils.clamp(desired.z, -2.7, 2.7);
      const dx = desired.x - root.position.x;
      velocity.x += dx * (10 + gravityRef.current * 1.8) * delta;
      velocity.x *= Math.pow(0.055, delta);
      root.position.x += velocity.x * delta;
      root.position.x = THREE.MathUtils.clamp(root.position.x, -4.35, 4.35);
      const dz = desired.z - root.position.z;
      velocity.z += dz * (10 + gravityRef.current * 1.8) * delta;
      velocity.z *= Math.pow(0.055, delta);
      root.position.z += velocity.z * delta;
      root.position.z = THREE.MathUtils.clamp(root.position.z, -2.9, 2.9);

      if (jumpRequested && Math.abs(root.position.y) < 0.02) velocity.y = 2.4 + gravityRef.current * 0.5;
      jumpRequested = false;
      velocity.y -= gravityRef.current * 2.5 * delta;
      root.position.y += velocity.y * delta;
      if (root.position.y < 0) {
        root.position.y = 0;
        if (velocity.y < -0.15) velocity.y *= -0.2;
        else velocity.y = 0;
      }
      const grounded = Math.abs(root.position.y) < 0.001 && Math.abs(velocity.y) < 0.05;
      const state = !grounded ? "En el aire" : Math.hypot(velocity.x, velocity.z) > 0.12 ? "Recorriendo la habitación" : "Apoyada";
      if (state !== lastPhysicsState) {
        lastPhysicsState = state;
        onPhysicsRef.current(`${state} · ${gravityRef.current.toFixed(1)} g`);
      }

      touchPulse = Math.max(0, touchPulse - delta * 2.9);
      touchTilt = THREE.MathUtils.lerp(touchTilt, 0, Math.min(1, delta * 5.2));
      const bob = grounded ? Math.sin(t * 2.1) * 0.018 : 0;
      root.rotation.x = THREE.MathUtils.lerp(root.rotation.x, (gravityRef.current - 1) * -0.025 + touchPulse * 0.018, Math.min(1, delta * 5));
      root.scale.setScalar(1 + touchPulse * 0.008);
      if (mixer) {
        mixer.update(delta);
        const requestedClip = Math.hypot(velocity.x, velocity.z) > 0.14
          ? animationClips.find(clip => /walk|run|locomotion/i.test(clip.name))
          : animationClips.find(clip => /idle|standing|relax/i.test(clip.name)) ?? animationClips[0];
        if (requestedClip && requestedClip.name !== activeClipKey) {
          const nextAction = mixer.clipAction(requestedClip);
          nextAction.reset().fadeIn(0.18).play();
          activeAction?.fadeOut(0.18);
          activeAction = nextAction;
          activeClipKey = requestedClip.name;
        }
      }
      fallback.rotation.y = Math.sin(t * 0.5) * 0.05;
      if (loadedModel) loadedModel.rotation.y = modelYaw + Math.sin(t * 0.5) * 0.05;
      fallback.position.y = 1.12 + bob;
      if (loadedModel) loadedModel.position.y = loadedModelBaseY + bob;
      const pulse = 1 + Math.sin(t * 2.8) * 0.04;
      gravityRing.scale.setScalar(pulse);
      ring2.rotation.z = t * 0.18;
      ring2.scale.setScalar(1 + Math.sin(t * 1.4) * 0.06);
      if (Math.hypot(velocity.x, velocity.z) > 0.08) root.rotation.y = THREE.MathUtils.lerp(root.rotation.y, Math.atan2(velocity.x, velocity.z), 0.06);
      if (expressionRef.current === "dormida") root.rotation.z = Math.sin(t * 0.7) * 0.025;
      else root.rotation.z = THREE.MathUtils.lerp(root.rotation.z, 0, 0.08);
      const breath = Math.sin(t * (1.35 + currentBehavior.energy * 0.35)) * (0.004 + currentBehavior.energy * 0.007);
      const livingSway = Math.sin(t * 0.48) * 0.012 * currentBehavior.energy;
      root.rotation.x += breath * 0.42;
      if (loadedModel) loadedModel.rotation.y = modelYaw + Math.sin(t * 0.42) * 0.035 + (currentBehavior.lookAtUser ? Math.sin(t * 0.27) * 0.018 : 0);
      if (currentBehavior.speaking && mouthTargets.length > 0) {
        const speechPulse = 0.18 + Math.abs(Math.sin(t * 8.5)) * 0.72;
        mouthTargets.forEach(({ mesh, index }) => { if (mesh.morphTargetInfluences) mesh.morphTargetInfluences[index] = THREE.MathUtils.lerp(mesh.morphTargetInfluences[index] ?? 0, speechPulse, Math.min(1, delta * 12)); });
      } else {
        mouthTargets.forEach(({ mesh, index }) => { if (mesh.morphTargetInfluences) mesh.morphTargetInfluences[index] = THREE.MathUtils.lerp(mesh.morphTargetInfluences[index] ?? 0, 0, Math.min(1, delta * 9)); });
      }
      const blinkCycle = t % 4.8;
      const blink = blinkCycle > 4.58 ? Math.sin(((blinkCycle - 4.58) / 0.22) * Math.PI) : 0;
      blinkTargets.forEach(({ mesh, index }) => { if (mesh.morphTargetInfluences) mesh.morphTargetInfluences[index] = blink; });
      controls.update();
      renderer.render(scene, camera);
      if (frame % 60 === 0) onPhysicsRef.current(`${state} · ${gravityRef.current.toFixed(1)} g`);
      requestAnimationFrame(tick);
    };
    tick();

    return () => {
      disposed = true;
      resizeObserver.disconnect();
      window.removeEventListener("keydown", onKeyDown);
      window.removeEventListener("keyup", onKeyUp);
      renderer.domElement.removeEventListener("pointerdown", onPointerDown);
      renderer.domElement.removeEventListener("pointermove", onPointerMove);
      renderer.domElement.removeEventListener("pointerup", onPointerUp);
      renderer.domElement.removeEventListener("pointercancel", onPointerUp);
      controls.dispose();
      renderer.dispose();
      mount.removeChild(renderer.domElement);
      scene.traverse(object => {
        if (object instanceof THREE.Mesh) {
          object.geometry.dispose();
          const materials = Array.isArray(object.material) ? object.material : [object.material];
          materials.forEach(item => item.dispose());
        }
      });
    };
  }, []);

  return <div ref={mountRef} className="nova-scene" aria-label="Escena 3D interactiva de Nova" />;
}
