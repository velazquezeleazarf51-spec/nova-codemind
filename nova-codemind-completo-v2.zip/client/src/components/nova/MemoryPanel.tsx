import { Brain, Check, Edit3, Lock, Sparkles, Trash2, X } from "lucide-react";
import type { MemoryItem } from "@/lib/novaState";

interface MemoryPanelProps { memories: MemoryItem[]; onConfirm: (id: string) => void; onDelete: (id: string) => void; }

export default function MemoryPanel({ memories, onConfirm, onDelete }: MemoryPanelProps) {
  return <section className="memory-panel panel-glass">
    <div className="panel-heading"><div><span className="eyebrow"><Brain size={13} /> APRENDIZAJE</span><h2>Lo que Nova recuerda</h2></div><span className="memory-count">{memories.length} activos</span></div>
    <div className="memory-explainer"><div className="explainer-icon"><Sparkles size={17} /></div><p>Nova observa repeticiones, no invade. Las memorias propuestas necesitan tu confirmación y cualquier recuerdo se puede borrar.</p></div>
    <div className="memory-list">{memories.map(memory => <article key={memory.id} className={`memory-card ${memory.status}`}><div className="memory-card-top"><span className={`memory-badge ${memory.status}`}>{memory.status === "confirmada" ? <Check size={12} /> : <Sparkles size={12} />}{memory.status === "confirmada" ? "Confirmada" : "Propuesta"}</span><span className="confidence">{memory.confidence}% confianza</span></div><h3>{memory.title}</h3><p>{memory.detail}</p><div className="memory-meta"><span>{memory.source}</span><span>{memory.createdAt}</span></div><div className="memory-actions">{memory.status === "propuesta" && <button className="action-primary" onClick={() => onConfirm(memory.id)}><Check size={13} /> Guardar</button>}<button className="action-ghost" aria-label={`Editar ${memory.title}`}><Edit3 size={13} /></button><button className="action-ghost danger" aria-label={`Borrar ${memory.title}`} onClick={() => onDelete(memory.id)}><Trash2 size={13} /></button></div></article>)}</div>
    <div className="privacy-note"><Lock size={14} /><div><strong>Privacidad íntima desactivada</strong><span>El contenido adulto no se guarda sin permiso explícito.</span></div><button aria-label="Cerrar aviso"><X size={14} /></button></div>
  </section>;
}
