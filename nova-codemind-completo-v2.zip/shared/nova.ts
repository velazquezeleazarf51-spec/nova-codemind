// Límites del chat de Nova compartidos entre cliente y servidor,
// para que nunca vuelvan a desincronizarse.

/** Máximo de mensajes que el cliente envía al modelo como contexto. */
export const CHAT_MAX_CONTEXT_MESSAGES = 20;
/** Máximo de mensajes que el servidor acepta por petición (margen sobre el cliente). */
export const CHAT_MAX_MESSAGES_PER_REQUEST = 40;
/** Longitud máxima de un mensaje individual. */
export const CHAT_MAX_MESSAGE_LENGTH = 4000;

/** Límite de peticiones al chat por cliente y ventana de tiempo. */
export const CHAT_RATE_LIMIT_MAX = 12;
export const CHAT_RATE_LIMIT_WINDOW_MS = 60_000;
