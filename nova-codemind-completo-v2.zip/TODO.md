
## Habitación viva y navegación libre

- [x] Nova vive dentro de una habitación decorada con estética cyberpunk magenta/cian, cama, escritorio, pantalla holográfica, ventana, estantería y luces ambientales.
- [x] Nova puede moverse por los ejes X/Z con WASD o flechas, saltar y recibir un destino mediante arrastre sin quedarse fija en pose T.
- [x] Cuando no hay control manual ni una pausa, Nova escoge destinos internos de forma autónoma, camina hacia ellos con amortiguación y gira según su dirección.
